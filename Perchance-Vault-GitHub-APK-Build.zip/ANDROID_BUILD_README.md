# Perchance Vault — Android APK build

This project is the Perchance Vault React/Vite app prepared for the SwapLab builder environment (Node.js 22, Java 21, Gradle 8.14.3, Capacitor 8.5.3). It keeps the existing UI and opens the default `https://perchance.org/chatter1` generator inside its existing browser frame.

## Build an APK with Android Studio (Windows/macOS/Linux)

1. Install Node.js 22 and Android Studio. In Android Studio's SDK Manager, install an Android SDK platform and Android SDK Build-Tools.
2. Extract this project and open a terminal in this folder.
3. Run (the project pins Capacitor core, Android, and CLI to 8.5.3):
   ```sh
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, wait for Gradle sync. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk`.

For command-line builds on macOS/Linux after Android SDK and Java 21 are installed:

```sh
npm run android:debug
```

## Build using GitHub Actions

The included `.github/workflows/build-android-apk.yml` builds a debug APK on pushes to `main`/`master` or when manually triggered. Push this project to a GitHub repository, then open **Actions > Build Android APK > Run workflow**. Download the `perchance-vault-debug-apk` artifact from the completed run.

## Important behavior / limitations

- This is a wrapper around the provided web app, not a rewrite of Perchance itself. It still requires internet access to load `perchance.org` and other online generators.
- The existing app uses an iframe and a browser-style storage bridge. Browser security restrictions, Perchance site policies, Android WebView behavior, downloads, clipboard access, and filesystem permissions may behave differently on Android and should be tested on the target phone.
- This source bundle does not include an Android SDK or prebuilt APK. The APK must be compiled with Android Studio or the included GitHub Actions workflow.
- The generated APK from this workflow is a debug build for testing/sideloading, not a Play Store-signed release. For Play Store distribution, configure a release signing key and build an Android App Bundle (AAB).
