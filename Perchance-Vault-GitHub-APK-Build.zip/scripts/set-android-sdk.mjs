import fs from 'node:fs';
import path from 'node:path';
const candidates = [
  'android/variables.gradle',
  'android/app/build.gradle',
  'android/build.gradle',
];
let changed = false;
for (const file of candidates) {
  if (!fs.existsSync(file)) continue;
  let source = fs.readFileSync(file, 'utf8');
  const before = source;
  source = source.replace(/(compileSdkVersion\s*[=:]\s*)\d+/g, (_match, prefix) => `${prefix}36`);
  source = source.replace(/(compileSdk\s*[=:]\s*)\d+/g, (_match, prefix) => `${prefix}36`);
  if (source !== before) {
    fs.writeFileSync(file, source);
    console.log(`Updated compile SDK to 36 in ${file}`);
    changed = true;
  }
}
if (!changed) {
  console.error('Could not find a compileSdk setting in the generated Android project.');
  process.exit(1);
}
